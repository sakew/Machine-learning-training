# Sentimental-Analysis_R

The purpose of this R code is to carry out sentiment analysis of tweets pertaining to India's 2016 demonetization policy. 

In 2016, the Government of India launched a demonetization policy which took 85% of Indian rupees out of circulation. The move was designed as a means of cracking down on "black money" and took everyone by surprise (to put it mildly). In the days that followed Indians took to Twitter en-masse to express their feelings. Many experts say demonetization was very unpoular while others say it was well received


What is Twitter's veridct?

Well the Twitter jury is out and the Twitter sentiment has been...........


